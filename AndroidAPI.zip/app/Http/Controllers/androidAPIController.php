<?php

namespace App\Http\Controllers;

use App\Models\tb_user;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class androidAPIController extends Controller
{

    public function loginAPI(Request $data_login)
    {
        $val = tb_user::where('username',$data_login->username)->first();
        if($val != null){
            if (Hash::check($data_login->password, $val->password)){
                return response()->json($val,200);
            }else{
                return response()->json("data not found",500);
            };
        }else{
          return response()->json("data not found",500);
        };
    }

    public function registerAPI(Request $data_register)
    {
            tb_user::create([
                'username'=>$data_register->username,
                'password'=>Hash::make($data_register->password),
                'nama_user'=>$data_register->nama_user,
                'tgl_lahir'=>$data_register->tgl_lahir,
                'gender'=>$data_register->gender,
                'alamat'=>$data_register->alamat,
                'email'=>$data_register->email,
                'telp'=>$data_register->telp,
            ]);
            $user = tb_user::where('username',$data_register->username)->first();
            return response()->json($user,200);
    }
}
